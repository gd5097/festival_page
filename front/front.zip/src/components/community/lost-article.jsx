import React from 'react';
import { css } from '@emotion/react';

export default function LostArticle() {
    return(
        <div css={css`
            background-color: white;
        `}>
            Lost Article
        </div>

    );
}