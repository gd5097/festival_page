import React from 'react';
import { css } from '@emotion/react';

export default function Suggestion() {
    return(
        <div css={css`
            background-color: white;
        `}>
            Suggestion
        </div>

    );
}