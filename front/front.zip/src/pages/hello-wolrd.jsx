import React from 'react';

import HelloWorld from '../components/hello-world';

export default function HelloWorldPage(){
    return(
        <HelloWorld/>
    );
}